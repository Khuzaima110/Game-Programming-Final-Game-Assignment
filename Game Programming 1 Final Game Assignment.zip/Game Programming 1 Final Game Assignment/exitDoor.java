import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class exitDoor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class exitDoor extends Actor
{
    /**
     * Act - do whatever the exitDoor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(isTouching(prisonerMarcus.class)) {
            removeTouching(prisonerMarcus.class);
        }
        if(isTouching(george.class)) {
            removeTouching(george.class);
        }
    }
}
