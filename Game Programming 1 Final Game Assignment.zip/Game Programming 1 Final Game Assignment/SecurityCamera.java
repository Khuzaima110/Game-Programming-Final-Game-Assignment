import greenfoot.*;

public class SecurityCamera extends Actor
{
    private int angle = -45;
    private int speed = 1;
    private LaserBeam laser;
    private boolean hacked = false;

    public void addedToWorld(World w)
    {
        laser = new LaserBeam();
        w.addObject(laser, getX(), getY());
    }

    public void act()
    {
        rotateCamera();

        // Only update laser if not hacked
        if (!hacked && laser != null) {
            updateLaser();
        }

        detectPlayer();
    }


    private void rotateCamera()
    {
        angle += speed;
        if (angle > 55 || angle < -55)
            speed = -speed;

        setRotation(angle);
    }


    private void updateLaser()
    {
        if (laser != null) {
            laser.setRotation(getRotation());
            laser.setLocation(getX(), getY());
        }
    }


    private void detectPlayer()
    {
        // If hacked, do nothing (no detection)
        if (hacked) return;

        // 1. Check if George is TOUCHING the camera → hack it
        Actor touchingGeorge = getOneIntersectingObject(george.class);
        if (touchingGeorge != null)
        {
            hacked = true;

            if (laser != null)
            {
                getWorld().removeObject(laser);
                laser = null;
            }

            return; // stop everything after hack
        }

        // 2. NORMAL LASER DETECTION (only when NOT hacked)
        int steps = 60;
        int stepSize = 5;

        double rad = Math.toRadians(getRotation());
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);

        for (int i = 0; i < steps; i++)
        {
            int dx = (int)(-i * stepSize * cos);
            int dy = (int)(-i * stepSize * sin);

            Actor g = getOneObjectAtOffset(dx, dy, george.class);
            Actor m = getOneObjectAtOffset(dx, dy, prisonerMarcus.class);

            if (g != null || m != null)
            {
                Greenfoot.setWorld(new Hallway());
                return;
            }
        }
    }
    
    public void hackLaser() {
       if (!hacked) {
          hacked = true;
          if (laser != null && getWorld() != null) {
            getWorld().removeObject(laser);
            laser = null;
          }
       }
    }

}
