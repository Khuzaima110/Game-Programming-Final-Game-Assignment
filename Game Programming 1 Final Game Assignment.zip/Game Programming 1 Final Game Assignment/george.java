import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class george here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class george extends Actor
{
    /**
     * Act - do whatever the george wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        controls();
        SecurityCamera cam = (SecurityCamera)getOneIntersectingObject(SecurityCamera.class);
        if (cam != null) {
        cam.hackLaser();   // remove laser
        }

    }
    
    private boolean willCollide(int nextX, int nextY) {
        // Temporarily move to the predicted position
        int currentX = getX();
        int currentY = getY();
        setLocation(nextX, nextY);

        boolean touchingWall = isTouching(sideJailBar.class) || isTouching(topViewJailBar.class)||
        isTouching(wall.class);

        // Move back to original location
        setLocation(currentX, currentY);

        return touchingWall;
    }
    
    private void movePredictive(int dx, int dy) {
        // Horizontal movement
        if (!willCollide(getX() + dx, getY())) {
            setLocation(getX() + dx, getY());
        }

        // Vertical movement 
        if (!willCollide(getX(), getY() + dy)) {
            setLocation(getX(), getY() + dy);
        }
    }
    
    public void controls() {
        int dx = 0;
        int dy = 0;

        if (Greenfoot.isKeyDown("a"))  dx = -3;
        if (Greenfoot.isKeyDown("d")) dx = 3;
        if (Greenfoot.isKeyDown("w"))    dy = -6;
        if (Greenfoot.isKeyDown("s"))  dy = 6;

        movePredictive(dx, dy);
    }
    
}
