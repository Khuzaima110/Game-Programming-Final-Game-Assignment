import greenfoot.*;

public class CopyOfSecurityCamera extends Actor
{
    private int angle = -45;
    private int speed = 1;
    private LaserBeam laser;
    private boolean hacked = false;

    public void addedToWorld(World w)
    {
        laser = new LaserBeam();
        w.addObject(laser, getX(), getY());
    }

    public void act()
    {
        rotateCamera();

        if (!hacked && laser != null) {
            updateLaser();
        }

        detectPlayer();
        checkHack();
    }

    private void rotateCamera()
    {
        angle += speed;
        if (angle > 45 || angle < -45)
            speed = -speed;

        setRotation(angle);
    }

    private void updateLaser()
    {
        if (laser != null) {
            laser.setRotation(getRotation());
            laser.setLocation(getX(), getY());
        }
    }

    private void detectPlayer()
    {
        if (hacked) return;  // laser off → no detection

        int steps = 60;
        int stepSize = 5;

        double rad = Math.toRadians(getRotation());
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);

        for (int i = 0; i < steps; i++)
        {
            int dx = (int)(i * stepSize * cos);
            int dy = (int)(i * stepSize * sin);

            Actor g = getOneObjectAtOffset(dx, dy, george.class);
            Actor m = getOneObjectAtOffset(dx, dy, prisonerMarcus.class);

            if (g != null || m != null)
            {
                Greenfoot.setWorld(new Hallway());
                return;
            }
        }
    }

    private void checkHack()
    {
        Actor g = getOneIntersectingObject(george.class);

        if (g != null && !hacked) 
        {
            hacked = true;

            if (laser != null && getWorld() != null) {
                getWorld().removeObject(laser);
                laser = null;
            }
        }
    }

    public void hackLaser()
    {
        if (!hacked) {
            hacked = true;

            if (laser != null && getWorld() != null) {
                getWorld().removeObject(laser);
                laser = null;
            }
        }
    }
}
