import greenfoot.*;

public class LaserBeam extends Actor
{
    public LaserBeam()
    {
        GreenfootImage img = new GreenfootImage(300, 3);
        img.setColor(Color.RED);
        img.fill();
        setImage(img);
    }

    public void act() {}
}

