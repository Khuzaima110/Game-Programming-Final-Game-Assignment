import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 600, 1); 
        prepare();
    }
    
    public void act()
    {
        IsGeorgeGone();
        if (IsGeorgeGone()) {
            NewHallway();
        }
    }
    
    private void NewHallway()
    {
        World Hallway =  new  Hallway();
        Greenfoot.setWorld(Hallway);
    }
    
    private boolean IsGeorgeGone()
    {
        if (getObjects(george.class).isEmpty() && getObjects(prisonerMarcus.class).isEmpty()) {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        sideJailBar sideJailBar = new sideJailBar();
        addObject(sideJailBar,28,247);
        sideJailBar sideJailBar2 = new sideJailBar();
        addObject(sideJailBar2,86,245);
        sideJailBar sideJailBar3 = new sideJailBar();
        addObject(sideJailBar3,143,244);
        sideJailBar sideJailBar4 = new sideJailBar();
        addObject(sideJailBar4,198,244);
        topViewJailBar topViewJailBar = new topViewJailBar();
        addObject(topViewJailBar,234,242);
        topViewJailBar topViewJailBar2 = new topViewJailBar();
        addObject(topViewJailBar2,234,293);
        topViewJailBar topViewJailBar3 = new topViewJailBar();
        addObject(topViewJailBar3,235,335);
        topViewJailBar topViewJailBar4 = new topViewJailBar();
        addObject(topViewJailBar4,235,388);
        topViewJailBar topViewJailBar5 = new topViewJailBar();
        addObject(topViewJailBar5,234,452);
        topViewJailBar topViewJailBar6 = new topViewJailBar();
        addObject(topViewJailBar6,233,509);
        topViewJailBar6.setLocation(226,581);
        removeObject(topViewJailBar4);
        prisonerMarcus prisonerMarcus = new prisonerMarcus();
        addObject(prisonerMarcus,83,432);
        removeObject(topViewJailBar6);
        removeObject(topViewJailBar5);
        removeObject(sideJailBar2);
        topViewJailBar topViewJailBar7 = new topViewJailBar();
        addObject(topViewJailBar7,233,512);
        topViewJailBar topViewJailBar8 = new topViewJailBar();
        addObject(topViewJailBar8,235,396);
        topViewJailBar topViewJailBar9 = new topViewJailBar();
        addObject(topViewJailBar9,235,456);
        removeObject(sideJailBar3);
        wall wall = new wall();
        addObject(wall,436,30);
        wall wall2 = new wall();
        addObject(wall2,436,89);
        wall wall3 = new wall();
        addObject(wall3,436,150);
        wall wall4 = new wall();
        addObject(wall4,436,206);
        wall wall5 = new wall();
        addObject(wall5,435,256);
        wall wall6 = new wall();
        addObject(wall6,435,309);
        wall wall7 = new wall();
        addObject(wall7,436,368);
        wall wall8 = new wall();
        addObject(wall8,436,424);
        wall wall9 = new wall();
        addObject(wall9,436,482);
        wall9.setLocation(436,504);
        wall wall10 = new wall();
        addObject(wall10,436,504);
        wall9.setLocation(434,468);
        weakPrisonGuard weakPrisonGuard = new weakPrisonGuard();
        addObject(weakPrisonGuard,234,57);
        obliviousPrisonGuard obliviousPrisonGuard = new obliviousPrisonGuard();
        addObject(obliviousPrisonGuard,516,79);
        lockedDoor lockedDoor = new lockedDoor();
        addObject(lockedDoor,76,246);
        sideJailBar sideJailBar5 = new sideJailBar();
        addObject(sideJailBar5,121,243);
        sideJailBar sideJailBar6 = new sideJailBar();
        addObject(sideJailBar6,158,242);
        george george = new george();
        addObject(george,152,343);
        ventilationWall ventilationWall = new ventilationWall();
        addObject(ventilationWall,265,537);
        ventilationWall ventilationWall2 = new ventilationWall();
        addObject(ventilationWall2,324,533);
        ventilationWall2.setLocation(334,532);
        ventilationWall2.setLocation(326,531);
        ventilationWall2.setLocation(331,535);
        ventilationWall2.setLocation(328,537);
        ventilationWall ventilationWall3 = new ventilationWall();
        addObject(ventilationWall3,334,484);
        ventilationWall3.setLocation(404,536);
        ventilationWall3.setLocation(404,536);
        ventilationWall3.setLocation(391,539);
        ventilationWall ventilationWall4 = new ventilationWall();
        addObject(ventilationWall4,386,488);
        ventilationWall4.setLocation(420,540);
        ventilationWall3.setLocation(408,536);
        wall10.setLocation(385,536);
        wall10.setLocation(360,499);
        wall10.setLocation(366,442);
        wall10.setLocation(356,376);
        wall10.setLocation(431,513);
        wall10.setLocation(412,529);
        wall10.setLocation(366,535);
        wall10.setLocation(429,481);
        wall9.setLocation(432,485);
        wall9.setLocation(432,499);
        ventilationWall3.setLocation(360,536);
        ventilationWall4.setLocation(408,539);
        wall9.setLocation(431,458);
        wall10.setLocation(424,535);
        wall10.setLocation(427,490);
        wall9.setLocation(428,496);
        wall8.setLocation(428,457);
        wall7.setLocation(427,412);
        wall6.setLocation(428,360);
        wall5.setLocation(423,322);
        wall5.setLocation(429,293);
        wall5.setLocation(428,300);
        wall4.setLocation(422,266);
        wall4.setLocation(424,228);
        wall4.setLocation(429,239);
        wall3.setLocation(424,175);
        wall3.setLocation(436,139);
        wall3.setLocation(429,165);
        wall3.setLocation(428,174);
        wall2.setLocation(428,127);
        wall.setLocation(376,233);
        removeObject(wall);
        obliviousPrisonGuard.setLocation(506,256);
        obliviousPrisonGuard.setLocation(507,223);
        unlockedDoor unlockedDoor = new unlockedDoor();
        addObject(unlockedDoor,508,75);
        ventilationWall ventilationWall5 = new ventilationWall();
        addObject(ventilationWall5,416,94);
        wall2.setLocation(482,99);
        ventilationWall5.setLocation(440,98);
        wall2.setLocation(449,98);
        wall2.setLocation(452,98);
        unlockedDoor.setLocation(492,96);
        unlockedDoor.setLocation(501,61);
        unlockedDoor.setLocation(529,86);
        ventilationWall ventilationWall6 = new ventilationWall();
        addObject(ventilationWall6,529,86);
        ventilationWall6.setLocation(564,86);
        ventilationWall6.setLocation(549,82);
        ventilationWall ventilationWall7 = new ventilationWall();
        addObject(ventilationWall7,549,82);
        ventilationWall6.setLocation(559,99);
        ventilationWall6.setLocation(560,60);
        ventilationWall7.setLocation(572,103);
        ventilationWall7.setLocation(566,96);
        ventilationWall6.setLocation(549,92);
        ventilationWall6.setLocation(549,96);
        ventilationWall6.setLocation(560,92);
        wall2.setLocation(352,150);
        wall2.setLocation(424,117);
        wall2.setLocation(438,105);
        wall2.setLocation(419,123);
        ventilationWall5.setLocation(476,85);
        ventilationWall5.setLocation(468,86);
        wall2.setLocation(416,107);
        removeObject(wall2);
        ventilationWall5.setLocation(426,130);
        ventilationWall5.setLocation(459,132);
        unlockedDoor.setLocation(496,117);
        unlockedDoor.setLocation(514,94);
        unlockedDoor.setLocation(513,115);
        unlockedDoor.setLocation(512,113);
        unlockedDoor.setLocation(508,113);
        ventilationWall6.setLocation(548,135);
        unlockedDoor.setLocation(528,130);
        ventilationWall7.setLocation(571,131);
        ventilationWall7.setLocation(564,131);
        ventilationWall7.setLocation(557,132);
        ventilationWall7.setLocation(547,135);
        unlockedDoor.setLocation(527,132);
        unlockedDoor.setLocation(560,130);
        ventilationWall7.setLocation(558,130);
        ventilationWall7.setLocation(558,130);
        ventilationWall6.setLocation(584,126);
        ventilationWall6.setLocation(588,127);
        ventilationWall6.setLocation(558,132);
        ventilationWall6.setLocation(596,131);
        unlockedDoor.setLocation(503,87);
        unlockedDoor.setLocation(508,113);
        ventilationWall5.setLocation(444,133);
        unlockedDoor.setLocation(544,128);
        unlockedDoor.setLocation(546,124);
        ventilationWall7.setLocation(556,132);
        unlockedDoor.setLocation(495,83);
        unlockedDoor.setLocation(499,81);
        unlockedDoor.setLocation(503,103);
        removeObject(ventilationWall7);
        ventilationWall6.setLocation(555,131);
        ventilationWall6.setLocation(561,136);
        ventilationWall6.setLocation(572,135);
        ventilationWall6.setLocation(569,130);
        ventilationWall6.setLocation(559,133);
        ventilationWall6.setLocation(593,127);
        ventilationWall6.setLocation(593,127);
        exitDoor exitDoor = new exitDoor();
        addObject(exitDoor,318,28);
        removeObject(exitDoor);
        addObject(exitDoor,69,33);
    }
}
